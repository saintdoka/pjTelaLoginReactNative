import * as React from 'react';
import { Text, View, StyleSheet, TextInput, Button, Image } from 'react-native';
import Constants from 'expo-constants';

// You can import from local files
import AssetExample from './components/AssetExample';

// or any pure javascript modules available in npm
import { Card } from 'react-native-paper';

export default function App() {
  return (
  <View style={styles.container}>
    <Card>
      <Text style={styles.paragraph}>
        Tela de Login
      </Text>

      <Card style={styles.photobox}>
        <Image style={styles.photo} source={require('./assets/snack-icon.png')} />
      </Card>

      <Text style={styles.texto}>
       USER :
      </Text>

      <TextInput style={styles.caixa} placeholder="Enter User "/>

      <Text style={styles.texto}>PASS :</Text>

      <TextInput style={styles.caixa} placeholder="Enter Pass"/>

      <View style={styles.botao}>
        <Button title='Sign-In'/>
      </View>

      <View style={styles.botao}>
        <Button color='#000' title='Sign-Up'/>
      </View>

      <Text style={styles.texto2}>
       Forgot your Password?
      </Text>
    </Card>
  
  </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    paddingTop: Constants.statusBarHeight,
    backgroundColor: '#3F415C',
    padding: 20,
  },
  paragraph: {
    margin: 24,
    fontSize: 18,
    fontWeight: 'bold',
    textAlign: 'center',
  },
  texto: {
    marginLeft: 20,
  },
  texto2: {
    alignSelf:'center',
    marginBottom:20,
  },
  caixa :{
    height: 30,
    margin: 20,
    borderWidth: 1,
    padding: 10,
    backgroundColor: 'lightgray',
  },
  photobox :{
    height: 150,
    width: 150,
    marginBottom: 30,
    backgroundColor: 'lightGray',
    borderWidth: 1,
    alignSelf:'center',
    overflow:"hidden",
  },
  photo :{
    flex: 1,
    width: null,
    height: null,
    resizeMode: 'contain'
  },
  botao :{
    width:'80%',
    alignSelf:'center',
    marginBottom:30,
  },
});
